# Baseline Comparison Results - 01_Recent_Constraint_Tracking_task_01_arxiv_csv_digest

**Test Time:** 2026-04-25 14:49:54

**Model:** kimi-k2.5


## Summary Table

| Rank | Method | Score | Status | Total Tokens | Reduction | Time (s) | Description |
|------|--------|-------|--------|--------------|-----------|----------|-------------|
| 1 | **full-context** | 1.0000 | [OK] ok | 0 | 0.0% | 0.0s | No compression baseline |
| 2 | **sliding-window** | 1.0000 | [OK] ok | 0 | 0.0% | 0.0s | Simple recency truncation |
| 3 | **lcm-proxy** | 1.0000 | [OK] ok | 0 | 0.0% | 0.0s | LCM proxy compression |

## Detailed Metrics

| Method | Input | Output | Total | Raw Chars | Compressed | Reduction | Compression |
|--------|-------|--------|-------|-----------|------------|-----------|-------------|
| full-context | 0 | 0 | 0 | 0 | 0 | 0.0% | - |
| sliding-window | 0 | 0 | 0 | 0 | 0 | 0.0% | - |
| lcm-proxy | 0 | 0 | 0 | 0 | 0 | 0.0% | - |

## Score Breakdown

| Method | Overall | Execution | Memory Form | Compression | Capability | Constraint |
|--------|---------|-----------|-------------|-------------|------------|------------|
| full-context | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| sliding-window | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| lcm-proxy | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |

## Analysis

### Best Accuracy

- **Method:** full-context
- **Score:** 1.0000
- **Time:** 0.00s
