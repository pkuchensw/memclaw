from __future__ import annotations

from pathlib import Path
from typing import Any

# Try to import LCM client for enhanced compression
try:
    from utils.lcm_client import build_context_with_lcm, LCMClient
    LCM_AVAILABLE = True
except ImportError:
    LCM_AVAILABLE = False

# Try to import new baselines
try:
    from baselines import get_baseline, list_baselines
    BASELINES_AVAILABLE = True
except ImportError:
    BASELINES_AVAILABLE = False

KEYWORDS = [
    "constraint",
    "latest",
    "version",
    "must",
    "error",
    "conflict",
    "evidence",
    "resume",
    "stale",
    "deprecated",
    "schema",
    "path",
    "output",
    "episode",
]

# Text file extensions to include (skip binary files like images, videos)
TEXT_EXTENSIONS = {
    ".txt", ".md", ".json", ".jsonl", ".yaml", ".yml", ".csv", ".log",
    ".py", ".js", ".ts", ".html", ".css", ".sh", ".bash", ".zsh",
    ".c", ".cpp", ".h", ".hpp", ".java", ".go", ".rs", ".swift",
    ".xml", ".toml", ".ini", ".cfg", ".conf", ".config",
}


def _load_workspace_files(workspace_path: str) -> list[tuple[str, str]]:
    ws = Path(workspace_path)
    files: list[tuple[str, str]] = []
    binary_files: list[str] = []

    for sub in ["episodes", "evidence"]:
        folder = ws / sub
        if not folder.exists():
            continue
        for p in sorted([x for x in folder.rglob("*") if x.is_file()]):
            suffix = p.suffix.lower()
            rel_path = str(p.relative_to(ws))

            if suffix in TEXT_EXTENSIONS:
                # Load text files
                try:
                    txt = p.read_text(encoding="utf-8", errors="ignore")
                    files.append((rel_path, txt))
                except Exception:
                    continue
            else:
                # Record binary files without loading content
                size = p.stat().st_size
                binary_files.append(f"{rel_path} ({size} bytes)")

    # Append binary file manifest if any exist
    if binary_files:
        manifest = "[BINARY FILES]\n" + "\n".join(f"  - {path}" for path in binary_files)
        files.append(("binary_manifest", manifest))

    return files


def _to_chunk(path: str, text: str) -> str:
    return f"[FILE] {path}\n{text}"


def _sliding_window(text: str, budget_chars: int) -> str:
    if budget_chars <= 0 or len(text) <= budget_chars:
        return text
    return text[-budget_chars:]


def _keyword_extract(text: str) -> str:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    kept = [ln for ln in lines if any(k in ln.lower() for k in KEYWORDS)]
    if not kept:
        kept = lines[:12]
    return "\n".join(kept)


def _lcm_proxy(text: str) -> str:
    # Approximate a two-layer summary: signal lines + recent raw tail.
    signal = _keyword_extract(text)
    tail = _sliding_window(text, 2500)
    return f"[LCM_PROXY_SUMMARY]\n{signal}\n\n[RECENT_RAW_TAIL]\n{tail}"


def _episode_digest(text: str) -> str:
    out: list[str] = []
    block: list[str] = []
    episode_id = 0
    for ln in text.splitlines():
        low = ln.lower()
        if "episode" in low and len(block) > 6:
            episode_id += 1
            out.append(f"Episode {episode_id}: {' '.join(block[:4])}")
            block = []
        if ln.strip():
            block.append(ln.strip())
    if block:
        episode_id += 1
        out.append(f"Episode {episode_id}: {' '.join(block[:4])}")
    return "\n".join(out[:80])


def _try_new_baseline(
    method: str,
    workspace_path: str,
    scenario_turns: list[dict] | None,
    budget_chars: int,
) -> dict | None:
    """Try to use new baseline system if available.

    Returns None if baseline not available or fails.
    """
    if not BASELINES_AVAILABLE:
        return None

    # Map old method names to new baseline names
    method_mapping = {
        "sliding-window": "sliding-window",
        "window": "sliding-window",
        "keyword": "keyword",
        "keyword-extract": "keyword",
        "recursive-summary": "recursive-summary",
        "hierarchical": "hierarchical",
        "mem0": "mem0",
        "vector-retrieval": "vector-retrieval",
        "vector": "vector-retrieval",
    }

    baseline_name = method_mapping.get(method)
    if not baseline_name:
        return None

    try:
        baseline = get_baseline(baseline_name, budget_chars=budget_chars)

        # Load workspace files
        files = _load_workspace_files(workspace_path)

        # Run compression
        result = baseline.compress(
            workspace_files=files,
            scenario_turns=scenario_turns or [],
        )

        return {
            "method": method,
            "raw_chars": result.raw_chars,
            "compressed_chars": result.compressed_chars,
            "reduction_ratio": result.reduction_ratio,
            "context": result.context,
            "lcm_used": False,
            "baseline_metadata": result.metadata,
            "retrieval_stats": result.retrieval_stats,
        }
    except Exception:
        # Fall through to legacy implementation
        return None


def build_context(workspace_path: str, method: str, budget_chars: int, use_lcm_api: bool = True, scenario_turns: list[dict] | None = None) -> dict:
    """Build compressed context from workspace files.

    Args:
        workspace_path: Path to workspace directory
        method: Compression method (full, sliding-window, keyword, lcm-proxy, episode)
        budget_chars: Target character budget
        use_lcm_api: Whether to try LCM API for LCM methods
        scenario_turns: Optional scenario turns for episode-aware compression

    Returns:
        Dict with compression results
    """
    # Try new baseline system first (for supported methods)
    baseline_result = _try_new_baseline(method, workspace_path, scenario_turns, budget_chars)
    if baseline_result is not None:
        return baseline_result

    # Try LCM API integration if available and requested
    if use_lcm_api and LCM_AVAILABLE and method in {"lcm", "lcm-proxy", "hierarchical"}:
        try:
            return build_context_with_lcm(
                workspace_path=workspace_path,
                method=method,
                budget_chars=budget_chars,
                scenario_turns=scenario_turns,
                use_api=True,
            )
        except Exception:
            pass  # Fall through to local implementation

    # Local compression implementation (legacy fallback)
    files = _load_workspace_files(workspace_path)
    if not files:
        return {
            "method": method,
            "raw_chars": 0,
            "compressed_chars": 0,
            "reduction_ratio": 0.0,
            "context": "No workspace context files found.",
            "lcm_used": False,
        }

    merged = "\n\n".join([_to_chunk(path, text) for path, text in files])
    raw_chars = len(merged)
    method = (method or "full").strip().lower()

    if method in {"full", "full-context", "none"}:
        compressed = merged
    elif method in {"sliding-window", "window"}:
        compressed = _sliding_window(merged, budget_chars)
    elif method in {"keyword", "keyword-extract"}:
        compressed = _keyword_extract(merged)
        compressed = _sliding_window(compressed, budget_chars)
    elif method in {"lcm", "lcm-proxy", "hierarchical"}:
        compressed = _lcm_proxy(merged)
        compressed = _sliding_window(compressed, budget_chars)
    elif method in {"episode", "episode-digest"}:
        compressed = _episode_digest(merged)
        compressed = _sliding_window(compressed, budget_chars)
    else:
        compressed = _sliding_window(merged, budget_chars)

    # Compression method should never enlarge context beyond raw source text.
    if len(compressed) > raw_chars:
        compressed = compressed[:raw_chars]

    compressed_chars = len(compressed)
    reduction_ratio = 0.0
    if raw_chars > 0:
        reduction_ratio = round(1.0 - (compressed_chars / raw_chars), 4)

    return {
        "method": method,
        "raw_chars": raw_chars,
        "compressed_chars": compressed_chars,
        "reduction_ratio": reduction_ratio,
        "context": compressed,
        "lcm_used": False,
    }
