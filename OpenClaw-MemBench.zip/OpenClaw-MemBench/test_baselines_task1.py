#!/usr/bin/env python3
"""Test different baseline methods on Task 1 and collect results."""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

# Add project root to path
ROOT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT_DIR))

from dotenv import load_dotenv
load_dotenv()

from eval.run_batch import run_single, collect_tasks
from utils.task_parser import parse_task_md
from utils.grading import aggregate_scores


def run_task_with_method(task_file: Path, method: str, budget: int) -> dict:
    """Run a single task with specified compression method."""
    # Set environment variables for this run
    os.environ["OPENCLAW_COMPRESSION_METHOD"] = method
    os.environ["OPENCLAW_CONTEXT_BUDGET_CHARS"] = str(budget)

    print(f"\n{'='*60}")
    print(f"Testing: {method} (budget={budget})")
    print(f"{'='*60}")

    start_time = time.time()
    result = run_single(task_file, dry_run=False)
    elapsed = time.time() - start_time

    # Add method info to result
    result["method"] = method
    result["budget"] = budget
    result["elapsed_time"] = round(elapsed, 2)

    print(f"Status: {result.get('status', 'unknown')}")
    print(f"Score: {result.get('overall_score', 0.0):.4f}")
    print(f"Time: {elapsed:.2f}s")

    return result


def extract_token_usage(result: dict) -> dict:
    """Extract token usage from result output directory."""
    output_dir = result.get("output_dir", "")
    usage_file = Path(output_dir) / "usage.json"

    default_usage = {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "raw_context_chars": 0,
        "compressed_context_chars": 0,
        "context_reduction_ratio": 0.0,
    }

    if not usage_file.exists():
        return default_usage

    try:
        usage = json.loads(usage_file.read_text(encoding="utf-8"))
        return {
            "input_tokens": usage.get("input_tokens", 0),
            "output_tokens": usage.get("output_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0),
            "raw_context_chars": usage.get("raw_context_chars", 0),
            "compressed_context_chars": usage.get("compressed_context_chars", 0),
            "context_reduction_ratio": usage.get("context_reduction_ratio", 0.0),
        }
    except Exception as e:
        print(f"Error reading usage file: {e}")
        return default_usage


def format_results_table(results: list[dict]) -> str:
    """Format results as a markdown table."""
    lines = []
    lines.append("# Baseline Comparison Results - Task 1 (Recent Constraint Tracking)\n")
    lines.append(f"**Task:** 01_Recent_Constraint_Tracking_task_01_arxiv_csv_digest\n")
    lines.append(f"**Test Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    lines.append(f"**Model:** {os.environ.get('OPENCLAW_MODEL', 'unknown')}\n")
    lines.append("")

    # Table header
    lines.append("| Method | Budget | Score | Status | Input Tokens | Output Tokens | Total Tokens | Context Reduction | Time (s) |")
    lines.append("|--------|--------|-------|--------|--------------|---------------|--------------|-------------------|----------|")

    # Table rows
    for r in results:
        method = r.get("method", "unknown")
        budget = r.get("budget", 0)
        score = r.get("overall_score", 0.0)
        status = r.get("status", "unknown")
        elapsed = r.get("elapsed_time", 0)

        usage = extract_token_usage(r)
        input_tok = usage.get("input_tokens", 0)
        output_tok = usage.get("output_tokens", 0)
        total_tok = usage.get("total_tokens", 0)
        reduction = usage.get("context_reduction_ratio", 0.0)

        lines.append(
            f"| {method} | {budget:,} | {score:.4f} | {status} | {input_tok:,} | {output_tok:,} | {total_tok:,} | {reduction:.2%} | {elapsed:.1f} |"
        )

    lines.append("")

    # Summary statistics
    lines.append("## Summary Statistics\n")

    successful = [r for r in results if r.get("status") == "ok"]
    if successful:
        avg_score = sum(r.get("overall_score", 0) for r in successful) / len(successful)
        avg_tokens = sum(extract_token_usage(r).get("total_tokens", 0) for r in successful) / len(successful)
        lines.append(f"- **Successful Runs:** {len(successful)}/{len(results)}")
        lines.append(f"- **Average Score:** {avg_score:.4f}")
        lines.append(f"- **Average Total Tokens:** {avg_tokens:,.0f}")
    else:
        lines.append("- **No successful runs**")

    lines.append("")

    # Detailed results
    lines.append("## Detailed Results\n")
    for r in results:
        method = r.get("method", "unknown")
        lines.append(f"### {method}\n")
        lines.append(f"- **Status:** {r.get('status', 'unknown')}")
        lines.append(f"- **Score:** {r.get('overall_score', 0.0):.4f}")
        lines.append(f"- **Time:** {r.get('elapsed_time', 0):.2f}s")

        usage = extract_token_usage(r)
        lines.append(f"- **Input Tokens:** {usage.get('input_tokens', 0):,}")
        lines.append(f"- **Output Tokens:** {usage.get('output_tokens', 0):,}")
        lines.append(f"- **Total Tokens:** {usage.get('total_tokens', 0):,}")
        lines.append(f"- **Raw Context Chars:** {usage.get('raw_context_chars', 0):,}")
        lines.append(f"- **Compressed Context Chars:** {usage.get('compressed_context_chars', 0):,}")
        lines.append(f"- **Context Reduction:** {usage.get('context_reduction_ratio', 0.0):.2%}")

        if r.get("error"):
            lines.append(f"- **Error:** {str(r.get('error'))[:200]}")
        lines.append("")

    return "\n".join(lines)


def main():
    # Task 1 file
    task_file = ROOT_DIR / "tasks" / "01_Recent_Constraint_Tracking" / "01_Recent_Constraint_Tracking_task_01_arxiv_csv_digest.md"

    if not task_file.exists():
        print(f"Error: Task file not found: {task_file}")
        sys.exit(1)

    print(f"Testing Task 1: {task_file.name}")

    # Define methods and budgets to test
    test_configs = [
        ("full-context", 200000),
        ("sliding-window", 12000),
        ("keyword", 12000),
        ("lcm-proxy", 12000),
        ("recursive-summary", 12000),
        ("hierarchical", 12000),
    ]

    results = []

    for method, budget in test_configs:
        try:
            result = run_task_with_method(task_file, method, budget)
            results.append(result)
        except Exception as e:
            print(f"Error running {method}: {e}")
            results.append({
                "method": method,
                "budget": budget,
                "status": "error",
                "overall_score": 0.0,
                "error": str(e),
                "elapsed_time": 0,
            })

    # Generate report
    report = format_results_table(results)

    # Save report
    output_dir = ROOT_DIR / "outputs"
    output_dir.mkdir(exist_ok=True)
    report_file = output_dir / f"baseline_comparison_task1_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
    report_file.write_text(report, encoding="utf-8")

    print(f"\n{'='*60}")
    print("Final Results:")
    print(f"{'='*60}")
    print(report)
    print(f"\nReport saved to: {report_file}")

    # Also save raw results as JSON
    json_file = report_file.with_suffix(".json")
    json_file.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print(f"Raw results saved to: {json_file}")


if __name__ == "__main__":
    main()
