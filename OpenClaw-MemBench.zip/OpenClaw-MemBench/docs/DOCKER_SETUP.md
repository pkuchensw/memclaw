# OpenClaw-MemBench Docker 运行指南

本文档介绍如何在 Docker 环境中运行 OpenClaw-MemBench 测评。

## 快速开始

### 1. 环境准备

确保已安装：
- Docker Desktop 28.0+
- Python 3.10+
- Git Bash (Windows) / Bash (Linux/Mac)

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，配置 API 密钥
```

必须配置的变量：
```bash
OPENCLAW_BASE_URL=https://api.openai.com/v1
OPENCLAW_API_KEY=your-api-key
OPENCLAW_MODEL=gpt-4
```

### 3. 构建 Docker 镜像

```bash
# 使用最终版 Dockerfile
docker build -f docker/Dockerfile -t openclaw-membench:latest .
```

### 4. 运行测评

```bash
# Windows (Git Bash)
export MSYS_NO_PATHCONV=1
export OPENCLAW_DOCKER_IMAGE=openclaw-membench:latest
python eval/run_batch.py --category 01_Recent_Constraint_Tracking --max-tasks 1 --runtime openclaw-docker

# Linux/Mac
export OPENCLAW_DOCKER_IMAGE=openclaw-membench:latest
python eval/run_batch.py --category 01_Recent_Constraint_Tracking --max-tasks 1 --runtime openclaw-docker
```

## Docker 镜像说明

### 使用的 Dockerfile

项目使用 `docker/Dockerfile`，基于官方 OpenClaw 镜像，修复了关键问题：

**问题**：原镜像中 `/usr/local/bin/openclaw` 是指向 `/app/openclaw.mjs` 的符号链接。运行时 workspace 被挂载到 `/app`，导致 openclaw 命令失效。

**解决方案**：将 openclaw 复制到 `/opt/openclaw/`，该位置不会被挂载覆盖。

### Dockerfile 内容

```dockerfile
FROM ghcr.io/openclaw/openclaw:2026.4.15

USER root

# 将 openclaw 复制到不会被挂载覆盖的位置
RUN mkdir -p /opt/openclaw /tmp_workspace /tmp_output /root/.openclaw && \
    cp -r /app/* /opt/openclaw/ && \
    chmod 777 /tmp_workspace /tmp_output && \
    rm -f /usr/local/bin/openclaw && \
    ln -s /opt/openclaw/openclaw.mjs /usr/local/bin/openclaw && \
    chmod +x /usr/local/bin/openclaw

ENV PATH="/usr/local/bin:${PATH}"
ENV HOME=/root

ENTRYPOINT []

RUN openclaw --version

WORKDIR /root
CMD ["tail", "-f", "/dev/null"]
```

## 运行参数

### 命令行参数

```bash
python eval/run_batch.py \
  --runtime openclaw-docker \      # 使用 Docker 运行环境
  --category 01_Recent_Constraint_Tracking \  # 任务类别
  --max-tasks 1 \                   # 最大任务数
  --output outputs/summary.json     # 输出文件
```

### 环境变量

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `OPENCLAW_DOCKER_IMAGE` | Docker 镜像名 | `openclaw-membench:latest` |
| `OPENCLAW_BASE_URL` | API 基础 URL | (必须配置) |
| `OPENCLAW_API_KEY` | API 密钥 | (必须配置) |
| `OPENCLAW_MODEL` | 模型名称 | (必须配置) |
| `MSYS_NO_PATHCONV` | Windows 路径转换禁用 | `1` (Windows 必需) |

## 输出结果

运行成功后，结果保存在 `outputs/` 目录：

```
outputs/
├── summary.json                    # 测评结果汇总
└── 01_Recent_Constraint_Tracking/
    └── 01_Recent_Constraint_Tracking_task_01_arxiv_csv_digest/
        └── 20260424_231021/
            └── attempt_1/
                ├── agent.log       # Agent 运行日志
                ├── chat.jsonl      # 完整对话记录
                ├── usage.json      # Token 使用情况
                └── results/        # 任务输出结果
                    ├── arxiv_memory_rl.csv
                    ├── constraint_trace.json
                    ├── result.json
                    └── summary.md
```

## 常见问题

### 1. Windows 路径转换问题

**症状**：Docker 命令执行失败

**解决**：设置 `export MSYS_NO_PATHCONV=1`

### 2. openclaw 命令未找到

**症状**：`/bin/bash: line 1: openclaw: command not found`

**解决**：确保使用正确的 Dockerfile 构建镜像

### 3. API 连接失败

**症状**：Timeout 或 Connection Error

**解决**：检查 `.env` 中的 API 配置是否正确

## Baseline 对比测试

使用 `scripts/run_all_baselines.py` 脚本快速对比不同压缩方法的性能：

```bash
# 快速模式（3个方法，推荐用于验证环境）
python scripts/run_all_baselines.py --quick --category 01_Recent_Constraint_Tracking --task-num 1

# 完整模式（6个方法）
python scripts/run_all_baselines.py --category 01_Recent_Constraint_Tracking --task-num 1

# 测试所有任务
python scripts/run_all_baselines.py --category 01_Recent_Constraint_Tracking --all-tasks

# 仅验证结构（不调用 API）
python scripts/run_all_baselines.py --quick --dry-run --category 01_Recent_Constraint_Tracking --task-num 1
```

输出结果：
- `outputs/<task_id>/baseline_comparison_*.md` - Markdown 对比报告
- `outputs/<task_id>/baseline_comparison_*.json` - 原始数据

## 验证安装

```bash
# 1. 验证 Docker 镜像
docker images openclaw-membench:latest

# 2. 验证 openclaw 可用
docker run --rm openclaw-membench:latest openclaw --version

# 3. 运行测试任务
export OPENCLAW_DOCKER_IMAGE=openclaw-membench:latest
python eval/run_batch.py --category 01_Recent_Constraint_Tracking --max-tasks 1 --runtime openclaw-docker
```

## 可用任务类别

| 类别 ID | 名称 |
|---------|------|
| 01_Recent_Constraint_Tracking | Recent Constraint Tracking |
| 02_Version_Update | Version Update |
| 03_Procedure_Transfer | Procedure Transfer |
| 04_Repeated_Mistake_Prevention | Repeated Mistake Prevention |
| 05_Source_Conflict_Resolution | Source Conflict Resolution |
| 06_Memory_Operation_Selection | Memory Operation Selection |
| 07_Goal_Interruption_Resumption | Goal Interruption and Task Resumption |
| 08_Staleness_Applicability_Judgment | Staleness and Applicability Judgment |
